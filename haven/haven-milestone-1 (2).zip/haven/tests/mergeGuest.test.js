// Tests for the guest -> account merge. They use a real SQLite file
// (prisma/test.db), created by `npm test`. No network needed.
import { describe, it, expect, beforeEach } from "vitest";
import { prisma } from "../src/lib/db.js";
import { mergeGuestIntoUser, MergeConflictError } from "../src/lib/mergeGuest.js";

async function wipe() {
  await prisma.checklistProgress.deleteMany();
  await prisma.goBagItem.deleteMany();
  await prisma.profile.deleteMany();
  await prisma.userSettings.deleteMany();
  await prisma.guestSession.deleteMany();
  await prisma.user.deleteMany();
}

const makeUser = () => prisma.user.create({ data: { email: `u${Math.random()}@test.dev` } });
const makeGuest = () => prisma.guestSession.create({ data: { tokenHash: `h${Math.random()}` } });

beforeEach(wipe);

describe("mergeGuestIntoUser", () => {
  it("moves guest data into an empty account and removes the guest", async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.profile.create({ data: { guestId: guest.id, zip: "27502" } });
    await prisma.checklistProgress.create({ data: { guestId: guest.id, taskId: "z0-gutters", zone: 0 } });
    await prisma.goBagItem.create({ data: { guestId: guest.id, label: "Documents", category: "papers" } });

    await mergeGuestIntoUser({ guestId: guest.id, userId: user.id });

    expect(await prisma.profile.count({ where: { userId: user.id } })).toBe(1);
    expect(await prisma.checklistProgress.count({ where: { userId: user.id } })).toBe(1);
    expect(await prisma.goBagItem.count({ where: { userId: user.id } })).toBe(1);
    expect(await prisma.guestSession.count()).toBe(0);
  });

  it("throws and changes nothing when both sides have data and no choice is given", async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.checklistProgress.create({ data: { userId: user.id, taskId: "a", zone: 0 } });
    await prisma.checklistProgress.create({ data: { guestId: guest.id, taskId: "b", zone: 1 } });

    await expect(mergeGuestIntoUser({ guestId: guest.id, userId: user.id })).rejects.toBeInstanceOf(
      MergeConflictError
    );
    expect(await prisma.checklistProgress.count({ where: { userId: user.id } })).toBe(1);
    expect(await prisma.checklistProgress.count({ where: { guestId: guest.id } })).toBe(1);
    expect(await prisma.guestSession.count()).toBe(1);
  });

  it('keep "guest" replaces the account data, even with the same task id', async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.checklistProgress.create({ data: { userId: user.id, taskId: "same", zone: 0 } });
    await prisma.checklistProgress.create({ data: { userId: user.id, taskId: "old-only", zone: 1 } });
    await prisma.checklistProgress.create({ data: { guestId: guest.id, taskId: "same", zone: 0 } });

    await mergeGuestIntoUser({ guestId: guest.id, userId: user.id, keep: "guest" });

    const rows = await prisma.checklistProgress.findMany({ where: { userId: user.id } });
    expect(rows.map((r) => r.taskId)).toEqual(["same"]);
  });

  it('keep "account" discards the guest data and keeps the account data', async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.goBagItem.create({ data: { userId: user.id, label: "Meds", category: "health" } });
    await prisma.goBagItem.create({ data: { guestId: guest.id, label: "Toys", category: "pets" } });

    await mergeGuestIntoUser({ guestId: guest.id, userId: user.id, keep: "account" });

    const items = await prisma.goBagItem.findMany();
    expect(items.map((i) => i.label)).toEqual(["Meds"]);
    expect(await prisma.guestSession.count()).toBe(0);
  });

  it("just removes an empty guest", async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.checklistProgress.create({ data: { userId: user.id, taskId: "a", zone: 0 } });

    await mergeGuestIntoUser({ guestId: guest.id, userId: user.id });

    expect(await prisma.checklistProgress.count({ where: { userId: user.id } })).toBe(1);
    expect(await prisma.guestSession.count()).toBe(0);
  });

  it("keeps the account's existing settings when the guest has data and settings too", async () => {
    const user = await makeUser();
    const guest = await makeGuest();
    await prisma.userSettings.create({ data: { userId: user.id, highContrast: true } });
    await prisma.userSettings.create({ data: { guestId: guest.id, highContrast: false } });
    await prisma.goBagItem.create({ data: { guestId: guest.id, label: "Charger", category: "power" } });

    await mergeGuestIntoUser({ guestId: guest.id, userId: user.id });

    const settings = await prisma.userSettings.findMany();
    expect(settings).toHaveLength(1);
    expect(settings[0].userId).toBe(user.id);
    expect(settings[0].highContrast).toBe(true);
  });

  it("deleting a user removes all of their data (cascade)", async () => {
    const user = await makeUser();
    await prisma.profile.create({ data: { userId: user.id } });
    await prisma.goBagItem.create({ data: { userId: user.id, label: "x", category: "y" } });

    await prisma.user.delete({ where: { id: user.id } });

    expect(await prisma.profile.count()).toBe(0);
    expect(await prisma.goBagItem.count()).toBe(0);
  });
});
