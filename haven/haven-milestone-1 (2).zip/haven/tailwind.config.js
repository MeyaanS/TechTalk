/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Calm base palette. Alert colors (amber/red) are added later and
        // reserved for alert states only.
        ink: "#12262B",
        pine: { DEFAULT: "#1D5C57", dark: "#14433F" },
        mist: "#EDF2F1",
        line: "#C5D3D0",
        paper: "#FBFDFC",
        focus: "#1A4FD6",
      },
    },
  },
  plugins: [],
};
