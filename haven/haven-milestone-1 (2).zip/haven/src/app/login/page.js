import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/currentUser";
import { continueAsGuest, sendMagicLink } from "@/app/actions";

export const metadata = { title: "Sign in - Haven" };

export default async function LoginPage({ searchParams }) {
  const user = await getCurrentUser();
  if (user?.kind === "account") redirect("/dashboard");

  return (
    <div className="max-w-xl">
      <h1 className="text-4xl font-bold leading-tight">
        Get your home and household ready for fire season.
      </h1>
      <p className="mt-4 text-lg">
        Haven turns official fire-weather alerts into clear steps for you. You never need a password or a phone number.
      </p>

      {searchParams?.error === "email" && (
        <p role="alert" className="mt-6 rounded-lg border-2 border-ink bg-white p-4 font-bold">
          That email address does not look right. Check it and try again.
        </p>
      )}
      {searchParams?.deleted && (
        <p role="status" className="mt-6 rounded-lg border-2 border-line bg-mist p-4">
          Your account and data were deleted.
        </p>
      )}

      <div className="mt-8 grid gap-8 sm:grid-cols-2">
        <section aria-labelledby="signin-heading" className="flex flex-col">
          <h2 id="signin-heading" className="text-xl font-bold">Save your progress</h2>
          <p className="mt-1">We will email you a sign-in link.</p>
          <form action={sendMagicLink} className="mt-4 flex flex-1 flex-col gap-3">
            <label htmlFor="email" className="font-bold">Email address</label>
            <input id="email" name="email" type="email" autoComplete="email" required className="field" />
            <button type="submit" className="btn btn-primary mt-auto">Email me a sign-in link</button>
          </form>
        </section>

        <section aria-labelledby="guest-heading" className="flex flex-col">
          <h2 id="guest-heading" className="text-xl font-bold">Just look around</h2>
          <p className="mt-1">Use every feature as a guest. You can create an account later.</p>
          <form action={continueAsGuest} className="mt-4 flex flex-1 flex-col justify-end">
            <button type="submit" className="btn btn-secondary">Skip for now</button>
          </form>
        </section>
      </div>
    </div>
  );
}
