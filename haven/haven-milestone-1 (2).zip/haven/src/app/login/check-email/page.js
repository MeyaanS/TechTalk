export const metadata = { title: "Check your email - Haven" };

export default function CheckEmailPage() {
  return (
    <div className="max-w-xl">
      <h1 className="text-3xl font-bold">Check your email</h1>
      <p className="mt-4 text-lg">
        We sent you a sign-in link. Open it on this device. It works once and expires in 15 minutes.
      </p>
      {process.env.NODE_ENV !== "production" && (
        <p className="mt-6 rounded-lg border-2 border-line bg-mist p-4">
          Development mode: no email was sent. Look in the terminal where you ran <code>npm run dev</code> for the link.
        </p>
      )}
      <p className="mt-6">
        <a href="/login" className="link">Use a different email</a>
      </p>
    </div>
  );
}
