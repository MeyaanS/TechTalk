import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/currentUser";
import { getGuestFromCookie } from "@/lib/guest";
import { prisma } from "@/lib/db";
import { summarizeOwner } from "@/lib/mergeGuest";
import { resolveMerge } from "@/app/actions";

export const metadata = { title: "Which progress should we keep? - Haven" };

function describe(s) {
  const parts = [];
  parts.push(s.hasProfile ? "a household profile" : "no household profile");
  parts.push(`${s.tasksDone} checklist task${s.tasksDone === 1 ? "" : "s"} done`);
  parts.push(`${s.goBagItems} go-bag item${s.goBagItems === 1 ? "" : "s"}`);
  return parts.join(", ");
}

export default async function MergePage({ searchParams }) {
  const user = await getCurrentUser();
  const guest = await getGuestFromCookie();
  if (user?.kind !== "account" || !guest) redirect("/dashboard");

  const [guestSummary, accountSummary] = await Promise.all([
    summarizeOwner(prisma, { guestId: guest.id }),
    summarizeOwner(prisma, { userId: user.id }),
  ]);

  return (
    <div className="max-w-xl">
      <h1 className="text-3xl font-bold">Which progress should we keep?</h1>
      <p className="mt-4 text-lg">
        You have saved progress both as a guest and in your account. We will not overwrite either one without asking.
      </p>

      {searchParams?.error === "choose" && (
        <p role="alert" className="mt-6 rounded-lg border-2 border-ink bg-white p-4 font-bold">
          Choose one option to continue.
        </p>
      )}

      <form action={resolveMerge} className="mt-6">
        <fieldset className="space-y-4">
          <legend className="text-xl font-bold">Keep one set of progress</legend>
          <label className="flex min-h-[3rem] items-start gap-3 rounded-lg border-2 border-line bg-white p-4">
            <input type="radio" name="keep" value="guest" required className="mt-1.5 h-5 w-5" />
            <span>
              <span className="block font-bold">What I did as a guest</span>
              <span className="block">{describe(guestSummary)}</span>
            </span>
          </label>
          <label className="flex min-h-[3rem] items-start gap-3 rounded-lg border-2 border-line bg-white p-4">
            <input type="radio" name="keep" value="account" className="mt-1.5 h-5 w-5" />
            <span>
              <span className="block font-bold">What is already in my account</span>
              <span className="block">{describe(accountSummary)}</span>
            </span>
          </label>
        </fieldset>
        <p className="mt-4">The set you do not choose will be deleted.</p>
        <button type="submit" className="btn btn-primary mt-4 sm:w-auto">Continue</button>
      </form>
    </div>
  );
}
