import Link from "next/link";
import { requireUser } from "@/lib/currentUser";

export const metadata = { title: "Home - Haven" };

export default async function DashboardPage() {
  const user = await requireUser();
  return (
    <div>
      <h1 className="text-3xl font-bold">Welcome to Haven</h1>
      <p className="mt-4 max-w-xl text-lg">
        {user.kind === "guest"
          ? "You are using Haven as a guest."
          : `You are signed in as ${user.email}.`}
      </p>
      <p className="mt-4 max-w-xl">
        Next up: set up your household, work through your defensive-zone checklist, and see live fire-weather alerts for your area. Those features arrive in the next milestones.
      </p>
      <p className="mt-6">
        <Link href="/settings" className="link">Open settings</Link>
      </p>
    </div>
  );
}
