import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { GUEST_COOKIE, getGuestFromCookie } from "@/lib/guest";
import { mergeGuestIntoUser, ownerHasData } from "@/lib/mergeGuest";

/**
 * Login always lands here (see sendMagicLink in actions.js).
 * - No guest data to deal with  -> go to the dashboard.
 * - Only one side has data      -> merge silently, then dashboard.
 * - Both sides have data        -> ask the person which to keep (/merge).
 */
export async function GET(request) {
  const go = (path) => NextResponse.redirect(new URL(path, request.url));

  const session = await auth();
  if (!session?.user?.id) return go("/login");
  const userId = session.user.id;

  const guest = await getGuestFromCookie();
  if (!guest) return go("/dashboard");

  const [guestHas, userHas] = await Promise.all([
    ownerHasData(prisma, { guestId: guest.id }),
    ownerHasData(prisma, { userId }),
  ]);
  if (guestHas && userHas) return go("/merge");

  await mergeGuestIntoUser({ guestId: guest.id, userId });
  const res = go("/dashboard");
  res.cookies.delete(GUEST_COOKIE);
  return res;
}
