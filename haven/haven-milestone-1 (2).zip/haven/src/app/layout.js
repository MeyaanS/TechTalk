import "./globals.css";
import { Atkinson_Hyperlegible } from "next/font/google";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GuestBanner from "@/components/GuestBanner";
import { getCurrentUser } from "@/lib/currentUser";

// Atkinson Hyperlegible was designed for low-vision readers.
const font = Atkinson_Hyperlegible({ subsets: ["latin"], weight: ["400", "700"], display: "swap" });

export const metadata = {
  title: "Haven",
  description: "Get your home and household ready for wildfire season.",
};

export default async function RootLayout({ children }) {
  const user = await getCurrentUser();
  return (
    <html lang="en" className={font.className}>
      <body className="flex min-h-screen flex-col">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:p-3 focus:font-bold"
        >
          Skip to main content
        </a>
        <Header user={user} />
        {user?.kind === "guest" && <GuestBanner user={user} />}
        <main id="main" className="mx-auto w-full max-w-3xl flex-1 px-5 py-10">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
