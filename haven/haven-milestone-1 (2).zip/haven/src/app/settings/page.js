import Link from "next/link";
import { requireUser } from "@/lib/currentUser";
import { deleteEverything, logOut } from "@/app/actions";

export const metadata = { title: "Settings - Haven" };

export default async function SettingsPage({ searchParams }) {
  const user = await requireUser();
  return (
    <div className="max-w-xl space-y-10">
      <h1 className="text-3xl font-bold">Settings</h1>

      <section aria-labelledby="account-heading">
        <h2 id="account-heading" className="text-xl font-bold">Account</h2>
        {user.kind === "guest" ? (
          <>
            <p className="mt-2">
              You are a guest. Create an account to keep your progress if you clear your browser data.
            </p>
            <p className="mt-3">
              <Link href="/login" className="link">Create account to save your progress</Link>
            </p>
          </>
        ) : (
          <>
            <p className="mt-2">Signed in as {user.email}.</p>
            <form action={logOut} className="mt-3">
              <button type="submit" className="btn btn-secondary sm:w-auto">Log out</button>
            </form>
          </>
        )}
      </section>

      <section aria-labelledby="delete-heading">
        <h2 id="delete-heading" className="text-xl font-bold">Delete my account and data</h2>
        <p className="mt-2">
          This permanently deletes your profile, checklist progress, go-bag, and settings. It cannot be undone.
        </p>
        {searchParams?.error === "confirm" && (
          <p role="alert" className="mt-3 rounded-lg border-2 border-ink bg-white p-4 font-bold">
            Tick the box to confirm.
          </p>
        )}
        <form action={deleteEverything} className="mt-3 space-y-3">
          <label className="flex min-h-[3rem] items-center gap-3">
            <input type="checkbox" name="confirm" value="yes" required className="h-5 w-5" />
            <span>Yes, delete everything.</span>
          </label>
          <button type="submit" className="btn btn-secondary sm:w-auto">Delete my account and data</button>
        </form>
      </section>
    </div>
  );
}
