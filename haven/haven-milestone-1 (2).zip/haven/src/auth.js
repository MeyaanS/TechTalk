import NextAuth from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/db";

/**
 * Passwordless email "magic link" provider.
 * - Development: the link is printed to the terminal (no email service needed).
 * - Production: sent with Resend. Needs RESEND_API_KEY and EMAIL_FROM.
 */
const magicLink = {
  id: "email",
  type: "email",
  name: "Email",
  from: process.env.EMAIL_FROM || "Haven <no-reply@example.com>",
  maxAge: 15 * 60, // links work for 15 minutes
  options: {},
  async sendVerificationRequest({ identifier, url }) {
    if (process.env.NODE_ENV !== "production") {
      console.log("\n==============================================");
      console.log(`Magic link for ${identifier}:`);
      console.log(url);
      console.log("==============================================\n");
      return;
    }
    if (!process.env.RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not set. Cannot send sign-in emails.");
    }
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM,
        to: identifier,
        subject: "Your Haven sign-in link",
        text: `Use this link to sign in to Haven. It works once and expires in 15 minutes.\n\n${url}\n\nIf you did not ask for this, you can ignore this email.`,
      }),
    });
    if (!res.ok) throw new Error(`Email failed to send (${res.status}).`);
  },
};

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [magicLink],
  session: { strategy: "database" },
  pages: { signIn: "/login", verifyRequest: "/login/check-email" },
  callbacks: {
    // Make the user id available as session.user.id
    session({ session, user }) {
      session.user.id = user.id;
      return session;
    },
  },
});
