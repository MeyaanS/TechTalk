import Link from "next/link";

/**
 * @param {{user: import('@/lib/currentUser').CurrentUser|null}} props
 */
export default function Header({ user }) {
  return (
    <header className="border-b-2 border-line bg-white">
      <div className="mx-auto flex max-w-3xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-5 py-4">
        <Link href={user ? "/dashboard" : "/login"} className="text-2xl font-bold text-pine">
          Haven
        </Link>
        {user && (
          <nav aria-label="Main" className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <Link href="/dashboard" className="link">Home</Link>
            <Link href="/settings" className="link">Settings</Link>
            {user.kind === "guest" && (
              <Link href="/login" className="link">Create account to save your progress</Link>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
