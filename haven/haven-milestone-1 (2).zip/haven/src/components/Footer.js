/** Required on every page. */
export default function Footer() {
  return (
    <footer className="border-t-2 border-line bg-mist">
      <p className="mx-auto max-w-3xl px-5 py-5 text-base">
        Haven is a planning aid, not an official emergency service. In an emergency, call 911.
      </p>
    </footer>
  );
}
