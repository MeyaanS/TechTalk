import Link from "next/link";
import { prisma } from "@/lib/db";
import { dismissGuestBanner } from "@/app/actions";

/** Gentle, dismissible reminder shown to guests only. Works without JavaScript. */
export default async function GuestBanner({ user }) {
  const settings = await prisma.userSettings.findUnique({ where: { guestId: user.id } });
  if (settings?.guestBannerDismissed) return null;

  return (
    <section aria-label="Guest reminder" className="border-b-2 border-line bg-mist">
      <div className="mx-auto flex max-w-3xl flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
        <p>
          You are using Haven as a guest. If you clear your browser data, your progress will be lost.
        </p>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <Link href="/login" className="link">Create account to save your progress</Link>
          <form action={dismissGuestBanner}>
            <button type="submit" className="link">Dismiss</button>
          </form>
        </div>
      </div>
    </section>
  );
}
